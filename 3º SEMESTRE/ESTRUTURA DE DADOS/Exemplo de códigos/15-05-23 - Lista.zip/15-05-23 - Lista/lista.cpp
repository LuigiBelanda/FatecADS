//Importa��o das Bibliote�as
#include<conio.h>
#include<stdlib.h>
#include<stdio.h>
#include<ctype.h>
#include<string.h>
#include <locale.h>

//Defini��o do TAD - Tipo Abstrato de dados
typedef struct Aluno
{
    //Dados do Usu�rio
    int ra;
    //Dados do Sistema
    Aluno *prox;
};

//Subrotina para a cria��o de
Aluno *novoElemento(){
    Aluno *novo;

    //Solicita para o Sistema Operacional um espa�o de mem�ria
    novo = (Aluno*)malloc(sizeof(Aluno));
    if(novo == NULL){
        //Verifica se existe espa�o para alocar o no
        printf("\nN�o h� espa�o de mem�ria");
        exit(1);
    }
    //Preenche os dados do usu�rio
    printf("\nDigite o RA: ");
    scanf("%d",&novo->ra);
    return novo;
}

Aluno *localizaPorRA(Aluno *ini, int pRa){
    while((ini->prox != NULL) && (ini->prox->ra != pRa))
        ini = ini->prox;
    if(ini->prox != NULL)
        return ini;
    return NULL;
}

Aluno *insereInicio(Aluno *ini, Aluno *novo){
    novo->prox = ini;
    ini = novo;
    return ini;
}

Aluno *insereFim(Aluno *f, Aluno *novo){
    novo->prox = NULL;
    f->prox = novo;
    f = novo;
    return f;
}

void insereMeio(Aluno *aux, Aluno *novo){
    novo->prox = aux->prox;
    aux->prox = novo;
}


void insere(Aluno **ini, Aluno **f){
    Aluno *novo, *enc;
    int raprocurado;

    if(*ini == NULL){
        //Insere o primeiro elemento na lista
        //Cria o novo elemento
        novo = novoElemento();
        novo->prox = NULL;
        //Atualiza os ponteiros de In�cio e Fim da Lista
        *ini = novo;
        *f = novo;
    }else if(*ini == *f){
        //S� tem um elemento na lista
        //Cria o novo elemento
        novo = novoElemento();
        *f = insereFim(*f,novo);
    }else{
        //Tem mais de um elemento na lista
        //Solicita nome a ser localizado.
        printf("\nDigite o RA a ser localizado para Insercao: ");
        scanf ("%d", &raprocurado);
        //Verifica se n�o � o primeiro elemento
        if((*ini)->ra == raprocurado){
            //Cria o novo elemento
            novo = novoElemento();
            insereMeio(*ini,novo);
        }else{
            //Chama a rotina que localiza o elemento anterior ao que est� sendo procurado.
            enc = localizaPorRA(*ini,raprocurado);
            if(enc == NULL){
                //Se o RA n�o foi localizado
                printf("\nO RA n�o foi localizado.\n");
            }else{
                //Cria o novo elemento
                novo = novoElemento();
                enc = enc->prox;
                if(enc == *f) //Verifica se o elemento que foi procurado foi oultimo elemento da lista
                    *f = insereFim(*f,novo);
                else
                    insereMeio(enc,novo);
                }
            }
        }
    }


 Aluno *removeInicio(Aluno *enc){
    Aluno * aux;

    aux = enc;
    enc = enc->prox;
    free(aux);
    return enc;
}

 void removeMeio(Aluno *enc){
    Aluno *aux;

    aux = enc->prox;
    enc->prox = aux->prox;
    free(aux);
    //return enc;
}

Aluno *removeFim(Aluno *enc){
    Aluno *aux;

    aux = enc->prox;
    enc->prox = NULL;
    free(aux);
    return enc;
}

void remover(Aluno **ini, Aluno **f){
    int raprocurado;
    Aluno *enc;
    //Verifica se existem elemento para serem removidos
    if(*ini == NULL)
        printf("\nERRO: Infelizmente n�o � poss�vel remover elemento pois a lista est� vazia.\n");
    else{
        if(*ini == *f){
            //S� tem um elemento na lista
            printf("\n\nRemovendo... RA: %d \t", (*ini)->ra);
            *ini = removeInicio(*ini);
        }else{
            //Solicita o RA a ser removido
            printf("\nDigite o RA a ser procurado: ");
            scanf ("%d", &raprocurado);
            //Verifica se � o primeiro elemento a ser removido
           if((*ini)->ra == raprocurado){ //if((*ini)->ra == raprocurado)
                //Remove do in�cio;
                printf("\n\nRemovendo... RA: %d \t", (*ini)->ra);
                *ini = removeInicio(*ini);
            }else{
                //Chama a subrotina que encontra o elemento anterior para realizar a remo��o.
                enc = localizaPorRA(*ini,raprocurado);
                if(enc == NULL)
                    //Caso o elemento n�o tenha sido localizado na lista
                    printf("\nERRO: O nome n�o foi localizado para ser removido\n");
                else{
                    //Verifica se � o ultimo elemento da lista
                    printf("\n\nRemovendo... RA: %d \t", enc->prox->ra);
                    if(enc->prox == *f)
                        *f = removeFim(enc);
                    else
                        removeMeio(enc);
                }
            }
        }
    }
}

void listar(Aluno *ini){
    Aluno *aux = ini;
    if(aux == NULL)
        printf("\nERRO: Esta lista n�o possuem elementos para serem listados.\n");
    else{
        while(aux != NULL){
            printf("\n\nRA: %d \n", ini->ra);
            //pega o ponteiro do pr�ximo elemento a ser removido
            aux = aux->prox;
        }
    }
}

    //remove todos os elemento de uma lista
void esvaziar(Aluno **ini){
    Aluno *aux;

    while (*ini != NULL){
        //Salva o ponteiro do pr�ximo elemento da lista para n�o perde-lo
        aux = (*ini)->prox;
        //Remove o elemento
        free(*ini);
        //Atualiza o in�cio
        *ini = aux;
    }
}

int main(){

    setlocale(LC_ALL, "Portuguese"); //defini��o de linguagem para portugu�s

    //Inicializa o ponteiro inicio para verificar se possui elementos inseridos.
    Aluno *inicio = NULL, *fim;
    char op;

    do{
        printf("\n\nLista simplesmete Encadeada");
        printf("\nEscolha uma das op��es:\n1 - Inserir\n2 - Listar\n3 - Remover\n4 -Esvaziar\n5 - Sair\nQual � a op��o desejada: ");
        scanf ("%d", &op);
        switch (op){
            case 1:
                insere(&inicio,&fim);
                listar(inicio);
                break;
            case 2:
                listar(inicio);
            break;
            case 3:
                remover(&inicio,&fim);
                listar(inicio);
            break;
            case 4:
                esvaziar(&inicio);
                printf("\nLista completamente Removida\n");
                break;
            case 5:
                printf("\nExecutando procedimento de limpeza de dados antes de sair\n");
                esvaziar(&inicio);
                printf("Saindo do sistema");
                break;
            default:
                printf("\nOpcao invalida\n");
        }
    }while(op != 5);
    return 0;
}
